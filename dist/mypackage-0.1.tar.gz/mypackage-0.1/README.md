# mypackage
This library was as an example

# How to install

